/** @type {import('next').NextConfig} */
const nextConfig = {
  // Không cần experimental.serverComponentsExternalPackages nữa
}

module.exports = nextConfig